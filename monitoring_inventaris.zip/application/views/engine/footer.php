<div class="footer">
                    <div class="footer-left">
                        <span>&copy; 2014. Noric and Kreuzhev Application Development. All Rights Reserved.</span>
                    </div>
                </div><!--footer-->
                